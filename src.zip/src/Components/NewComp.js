import React, { Component } from 'react'
import image from "'/images";
export class NewComp extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
        message:"Subscribe to me",
        sub:"subscribe" 
    };
    }
    styles={
        fontStyle:"italic",color:"purple"
     };
     Buttonchange=()=>{
        this.setState({message:"Hit the bell icon",sub:"subscribed" 

        });
     };
  render() {
    return (
      <div class="App">
        <h3 style={this.styles}>{this.state.message}</h3>
     <button onClick={this.Buttonchange}>{this.state.sub}</button>
      </div>
    );
  }
}


export default NewComp