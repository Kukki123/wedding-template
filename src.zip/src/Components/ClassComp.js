import React from 'react';
export class ClassComp extends React.Components{
    render(){
        return <p> this is class componenet</p>;
    }
}
export class ClassComp1 extends React.Components{
    render(){
        return <p> this is new</p>;
    }
}
