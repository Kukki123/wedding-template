import React from 'react';
function FunctionComp(){
    return<p> This is about compoents</p>
}
export default FunctionComp;